# SelectorGuard v2.5 源码、编译与升级说明

源码基于上传的 `HT_SelectorGuard_v2_4_AllGrades_ManualMonitor_OneUpload.zip`。

## 关键改变

1. 预警首页的筛选入口位于顶部；页面宽度适配窄屏，最近7场弹窗不会横向超出屏幕。
2. 半场原规则不动；全场独立模式取消 4.00 最低赔率门槛，真实 Bet365 全场正确比分的原始赔率全部展示。没有可用盘口时仍显示真实赛程观察卡（有额度上限），缺失赔率统一为 `—`，不自动升级候选。
3. 全场有三张比分与真实赔率、8比分赔率对照、最近7场半场/全场赛果和积分排名弹窗。
4. 从任意 A/B/C/PASS 卡片点击“勾选”或“直接加入预警”，成功后跳到对应比赛的主单/保险单输入区域。通知按比赛ID打开这场比赛详情，内有“修改主单/保险单”快捷入口。
5. Watch8 旧预警/推送/比赛数据逻辑及定时提醒未重写；继续由现有服务同步。

## 在 GitHub Actions 中编译

- 将本 ZIP 文件作为单独文件上传到支持本项目编译工作流的仓库根目录。工作流优先解压 v2.5，需仓库预先存在 `.github/workflows/build-apk.yml`；仅上传 ZIP 到完全空白的新仓库不会自动创建可运行的工作流。
- 如新建仓库，应先将 ZIP **解压后的源码与 `.github/workflows/build-apk.yml`** 上传/提交到根目录，再打开 GitHub 仓库的 Actions 页，运行 `Build Watch8 44mm Phone and Wear APKs`。
- 本地已配置 Android SDK 35 和 Gradle 8.10.2 时，命令为 `gradle :app:assembleDebug :wear:assembleDebug --no-daemon --stacktrace --console=plain`。
- 构建产物 `app/build/outputs/apk/debug/app-debug.apk` 和 `wear/build/outputs/apk/debug/wear-debug.apk`；Actions 中分别命名 `HT-v2.5-Responsive-FT-NoPriceFloor-PHONE-APK` 与 `HT-v2.5-Responsive-FT-NoPriceFloor-WATCH-APK`。
- 同一源码携带原有测试用签名文件；升级之前请保留旧安装包和原始数据。切勿将此测试用签名或其他密钥用于正式发布。

## 测试状态

已通过所有项目 JavaScript 测试、Java 局部逻辑单元测试、JavaScript 语法检测以及 393 像素窄屏历史弹窗模拟；没有本机 Android SDK，因此尚未完成 Android APK 编译，也未做实体手机/手表真机推送跳转验证。
