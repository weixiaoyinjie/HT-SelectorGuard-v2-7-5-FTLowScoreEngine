package com.htlive.monitor;

import java.nio.file.Files;
import java.nio.file.Path;

public final class SelectorSnapshotStoreTest {
    public static void main(String[] args) throws Exception {
        Path dir=Files.createTempDirectory("selector-snapshot-test-");
        String ht="{\"version\":23,\"period\":\"HT\",\"ranked\":[{\"id\":1}]}";
        String ft="{\"version\":23,\"period\":\"FT\",\"ranked\":[{\"id\":2}]}";
        if(!SelectorSnapshotStore.load(dir.toFile(),"HT").isEmpty())throw new AssertionError("empty initial cache");
        SelectorSnapshotStore.save(dir.toFile(),"HT",ht);
        SelectorSnapshotStore.save(dir.toFile(),"FT",ft);
        if(!ht.equals(SelectorSnapshotStore.load(dir.toFile(),"HT")))throw new AssertionError("HT must be retained");
        if(!ft.equals(SelectorSnapshotStore.load(dir.toFile(),"FT")))throw new AssertionError("FT must be retained");
        SelectorSnapshotStore.save(dir.toFile(),"FT",ft.replace("id\\\":2","id\\\":3"));
        if(!ht.equals(SelectorSnapshotStore.load(dir.toFile(),"HT")))throw new AssertionError("HT must not be overwritten by FT");
        try{SelectorSnapshotStore.load(dir.toFile(),"../SECRET");throw new AssertionError("invalid mode was allowed");}
        catch(java.io.IOException expected){}
        try{SelectorSnapshotStore.save(dir.toFile(),"HT","not-json");throw new AssertionError("invalid input was allowed");}
        catch(java.io.IOException expected){}
        System.out.println("PASS: atomic private HT/FT scan caches, independent modes and invalid-input guards");
    }
}
