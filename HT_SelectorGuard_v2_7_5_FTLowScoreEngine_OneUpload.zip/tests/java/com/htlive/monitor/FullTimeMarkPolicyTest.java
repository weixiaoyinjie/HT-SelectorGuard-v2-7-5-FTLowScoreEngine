package com.htlive.monitor;
public final class FullTimeMarkPolicyTest {
    private static final long NOW=1_900_000_000_000L;
    static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        for(int mark:new int[]{60,75,85}){
            check(!FullTimeMarkPolicy.due("HT","2H",mark,NOW,NOW,mark),"HT must be untouched "+mark);
            check(!FullTimeMarkPolicy.due("FT","HT",mark,NOW,NOW,mark),"No halftime alert "+mark);
            check(!FullTimeMarkPolicy.due("FT","2H",mark-1,NOW,NOW,mark),"No premature alert "+mark);
            check(FullTimeMarkPolicy.due("FT","2H",mark,NOW-1000,NOW,mark),"Due at exact mark "+mark);
            check(FullTimeMarkPolicy.due("FT","2H",mark+8,NOW-1000,NOW,mark),"Allow genuine delayed refresh "+mark);
            check(!FullTimeMarkPolicy.due("FT","2H",mark+11,NOW-1000,NOW,mark),"Avoid very stale mark "+mark);
            check(!FullTimeMarkPolicy.due("FT","2H",mark,NOW-110000,NOW,mark),"Reject stale source "+mark);
        }
        check(!FullTimeMarkPolicy.due("FT","2H",61,NOW,NOW,30),"Do not duplicate HT marks");
        System.out.println("PASS: FT 60/75/85 reminder gate and HT isolation");
    }
}
