package com.htlive.watch44;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import org.json.JSONArray;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** A real, touch-operable Watch8 entry screen plus the original one-page alert detail. */
public final class WearAlertActivity extends Activity {
    private static final int NOTIFY_PERMISSION = 30;
    private static final int BG = Color.BLACK;
    private static final int ACCENT = 0xff55e2d4;
    private TextView statusView;
    private ScrollView activeScroll;
    private boolean showingDetail;
    private boolean showingMatches;
    private boolean listening;
    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (showingMatches) showMatches(false);
            else if (!showingDetail && statusView != null) statusView.setText(connectionStatus());
        }
    };

    private int dp(float x) { return (int)(getResources().getDisplayMetrics().density * x + .5f); }
    private SharedPreferences prefs() { return getSharedPreferences(WearAlertListener.PREF, MODE_PRIVATE); }
    private boolean hasNotifyPermission() {
        return Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        showIntent(getIntent());
    }
    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        showIntent(intent);
    }
    @Override protected void onStart() {
        super.onStart();
        if (!listening) {
            IntentFilter filter = new IntentFilter(WearAlertListener.STATUS_CHANGED);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(statusReceiver, filter);
            listening=true;
        }
    }
    @Override protected void onResume() {
        super.onResume();
        if (!showingDetail && statusView!=null) statusView.setText(connectionStatus());
    }
    @Override protected void onStop() {
        if(listening){unregisterReceiver(statusReceiver);listening=false;}
        super.onStop();
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] perms,int[] results) {
        super.onRequestPermissionsResult(requestCode,perms,results);
        if (requestCode==NOTIFY_PERMISSION) showHome();
    }
    @Override public void onBackPressed() {
        if(showingDetail || showingMatches){showHome();return;}
        super.onBackPressed();
    }
    private TextView label(String value,int sp,int color,boolean strong) {
        TextView tv=new TextView(this);
        tv.setText(value==null?"":value);tv.setTextColor(color);tv.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);
        tv.setGravity(Gravity.CENTER);tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        if(strong) tv.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        tv.setAutoSizeTextTypeUniformWithConfiguration(Math.max(9,sp-3),sp,1,TypedValue.COMPLEX_UNIT_SP);
        return tv;
    }
    private LinearLayout surface(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);
        int pixels=Math.min(getResources().getDisplayMetrics().widthPixels,getResources().getDisplayMetrics().heightPixels);
        LinearLayout col=new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);col.setGravity(Gravity.CENTER);
        col.setPadding(dp(1),dp(1),dp(1),dp(1));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams((int)(pixels*.80f),-2,Gravity.CENTER);
        root.addView(col,lp);
        // Limit the content width to the circular safe area; keep actual touch bounds intact.
        setContentView(root);
        return col;
    }
    private void add(LinearLayout col,View view,int h,int gap){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(h));lp.bottomMargin=dp(gap);
        col.addView(view,lp);
    }
    private TextView action(LinearLayout col,String text,int gap,boolean emphasized,Runnable onClick) {
        TextView tv=label(text,13,Color.WHITE,true);
        GradientDrawable shape=new GradientDrawable();
        shape.setColor(emphasized?0xff0c6059:0xff22313c);shape.setCornerRadius(dp(22));
        shape.setStroke(dp(1),emphasized?ACCENT:0xff527080);
        tv.setBackground(shape);tv.setClickable(true);tv.setFocusable(true);
        tv.setContentDescription(text);
        tv.setOnClickListener(v -> onClick.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(35));
        lp.leftMargin=dp(13);lp.rightMargin=dp(13);lp.bottomMargin=dp(gap);
        col.addView(tv,lp);
        return tv;
    }
    private static String flat(String s){return s==null?"":s.replace('\n',' ').replace('\r',' ').trim();}
    private String connectionStatus() {
        SharedPreferences p=prefs();
        long at=p.getLong("phone_pong_at",0);
        if(at>0 && System.currentTimeMillis()-at < 5*60_000L) return "手机已响应 · 连接正常";
        String message=p.getString("connection_status","");
        return message.isEmpty()?"尚未检测手机连接":message;
    }
    private void showIntent(Intent intent){
        if(intent!=null && intent.hasExtra("nid") && intent.getIntExtra("nid",-1)>=0){
            showDetail(intent.getIntExtra("nid",-1));
        }else showHome();
    }
    private void showHome(){
        showingDetail=false;
        showingMatches=false;
        statusView=null;
        LinearLayout col=scrollSurface();
        add(col,label("HT WATCH 8",16,ACCENT,true),25,1);
        add(col,label("赛况预警 · 手表端",15,Color.WHITE,true),24,5);
        add(col,label(hasNotifyPermission()?"通知权限：已开启":"通知权限：未开启",13,
            hasNotifyPermission()?ACCENT:0xffffb454,true),23,2);
        statusView=label(connectionStatus(),12,0xffb7c9d5,false);
        add(col,statusView,23,7);
        action(col,"检测手机连接",7,true,this::checkPhone);
        action(col,"查看手机同步赛况",7,true,() -> showMatches(true));
        action(col,"测试手表通知",7,false,this::localTest);
        if(!hasNotifyPermission())
            action(col,"开启通知权限",7,true,this::requestNotifyPermission);
        int latest=prefs().getInt("latest",-1);
        if(latest>=0)
            action(col,"查看最近一条赛况",7,false,() -> showDetail(latest));
        add(col,label("无需在手表填写 API · 手机端负责监控",10,0xff9aaebd,false),20,0);
    }
    private void requestNotifyPermission() {
        if(Build.VERSION.SDK_INT>=33 && !hasNotifyPermission())
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFY_PERMISSION);
        else showHome();
    }
    private void setStatus(String status) {
        prefs().edit().putString("connection_status",status).apply();
        if(!showingDetail && statusView!=null) statusView.setText(status);
    }
    private void checkPhone() {
        final String token=UUID.randomUUID().toString();
        prefs().edit().putString("pending_ping",token).putLong("phone_pong_at",0).apply();
        setStatus("正在查找手机…");
        try {
        Wearable.getNodeClient(this).getConnectedNodes()
            .addOnSuccessListener(nodes -> {
                if(nodes==null || nodes.isEmpty()){
                    setStatus("未发现连接的手机");return;
                }
                setStatus("已找到手机 · 等待 App 回应");
                for(Node node:nodes) {
                    Wearable.getMessageClient(this).sendMessage(node.getId(),"/scorepath/ping",
                        token.getBytes(StandardCharsets.UTF_8))
                        .addOnFailureListener(e -> setStatus("消息发送失败 · 检查手机端 App"));
                }
            })
            .addOnFailureListener(e -> setStatus("连接检测失败 · 检查配对"));
        } catch(Exception e) { setStatus("连接服务不可用 · 检查手表服务"); }
    }
    private void localTest() {
        if(!hasNotifyPermission()){
            setStatus("请先允许手表通知权限");
            requestNotifyPermission();
            return;
        }
        try {
            WearAlertListener.postDemo(this);
            setStatus("测试通知已发送 · 查看通知列表");
        }catch(Exception e){setStatus("通知测试失败："+e.getClass().getSimpleName());}
    }
    /** Scrollable safe-area content; unlike legacy labels it does not hide long phone analysis. */
    private LinearLayout scrollSurface(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);
        int d=Math.min(getResources().getDisplayMetrics().widthPixels,getResources().getDisplayMetrics().heightPixels);
        ScrollView scroll=new ScrollView(this);activeScroll=scroll;scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        FrameLayout.LayoutParams outer=new FrameLayout.LayoutParams((int)(d*.83f),(int)(d*.90f),Gravity.CENTER);
        root.addView(scroll,outer);
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(4),dp(12),dp(4),dp(18));scroll.addView(col);
        setContentView(root);return col;
    }
    private void paragraph(LinearLayout col,String content,int size,int color,boolean strong){
        TextView tv=new TextView(this);tv.setText(content==null?"":content);
        tv.setTextColor(color);tv.setTextSize(TypedValue.COMPLEX_UNIT_SP,size);
        tv.setGravity(Gravity.CENTER_HORIZONTAL);
        if(strong)tv.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        tv.setSingleLine(false);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.bottomMargin=dp(8);col.addView(tv,lp);
    }
    private static String value(JSONObject j,String key){
        if(j==null || !j.has(key) || j.isNull(key))return "—";
        return j.optString(key,"—");
    }
    private static String dual(JSONObject stats,String metric){
        JSONObject home=stats==null?null:stats.optJSONObject("home");
        JSONObject away=stats==null?null:stats.optJSONObject("away");
        return value(home,metric)+" / "+value(away,metric);
    }
    private static String MatchStatus(String state){
        switch(state){
            case "HIT":return "命中";
            case "PENDING":return "待达";
            case "BROKEN":return "失效";
            case "CLOSED":return "已结";
            default:return "待核";
        }
    }
    private static String freshness(long at,long now){
        if(at<=0)return "暂无可靠数据时间";
        long age=now-at;
        if(age< -30_000)return "手机/手表时间不同步，请核对时钟";
        long secs=Math.max(0,age/1000);
        if(secs>120)return "⚠ 数据滞后 "+secs+" 秒";
        return "采集于 "+secs+" 秒前";
    }
    private void requestSnapshot(){
        try {
            Wearable.getNodeClient(this).getConnectedNodes()
                .addOnSuccessListener(nodes->{
                    if(nodes==null || nodes.isEmpty()){setStatus("手表与手机未连接");return;}
                    for(Node node:nodes){
                        Wearable.getMessageClient(this).sendMessage(node.getId(),
                            "/scorepath/sync_request",new byte[]{1})
                            .addOnFailureListener(e->setStatus("同步请求失败，请检查手机"));
                    }
                }).addOnFailureListener(e->setStatus("连接失败，请检查配对"));
        }catch(Exception e){setStatus("同步服务不可用");}
    }
    private void showMatches(boolean refresh){
        final int previousY=(!refresh && showingMatches && activeScroll!=null)?activeScroll.getScrollY():0;
        showingDetail=false;showingMatches=true;statusView=null;
        if(refresh)requestSnapshot();
        LinearLayout col=scrollSurface();
        paragraph(col,"手机同步赛况",16,ACCENT,true);
        JSONObject snapshot=null;
        try{snapshot=new JSONObject(prefs().getString("snapshot_json","{}"));}
        catch(Exception ignored){}
        if(snapshot==null)snapshot=new JSONObject();
        long now=System.currentTimeMillis();
        paragraph(col,"最后一次成功更新："+freshness(snapshot.optLong("updatedAt",0L),now)+
            " · 手机间隔 "+snapshot.optInt("interval",60)+"秒",
            10,0xffffc37f,false);
        if(!snapshot.optString("error","").isEmpty()){
            paragraph(col,"⚠ 手机采集失败："+snapshot.optString("error")+
                "\n本页显示上次成功采集的数据，不代表实时比分。",
                11,0xffff9687,true);
        }
        JSONArray matches=snapshot.optJSONArray("matches");
        if(matches==null || matches.length()==0){
            paragraph(col,"暂无同步赛况。请在手机开启监控，并确认手表已配对。",12,Color.WHITE,false);
        }else for(int i=0;i<matches.length();i++){
            JSONObject m=matches.optJSONObject(i);if(m==null)continue;
            paragraph(col,("FT".equals(m.optString("period"))?"【全场 · 三张】":"【半场 · 两张】")+m.optString("home","主队")+" vs "+m.optString("away","客队"),13,ACCENT,true);
            paragraph(col,m.optString("h","?")+" - "+m.optString("a","?")+" · "+m.optInt("minute",0)+"′  "+m.optString("status","?"),
                19,Color.WHITE,true);
            JSONArray bets=m.optJSONArray("guardBets");
            if(bets!=null && bets.length()>0){
                StringBuilder b=new StringBuilder("我的单  ");
                JSONObject riskState=m.optJSONObject("guardRisk");
                JSONArray states=riskState==null?null:riskState.optJSONArray("items");
                for(int k=0;k<bets.length() && k<3;k++){
                    JSONObject bet=bets.optJSONObject(k);
                    if(bet==null)continue;
                    if(k>0)b.append("  ");
                    b.append(k==0?"主":"保").append(bet.optString("pick","?"));
                    JSONObject status=states!=null&&k<states.length()?states.optJSONObject(k):null;
                    if(status!=null)b.append("(").append(MatchStatus(status.optString("state",""))).append(")");
                }
                paragraph(col,b.toString(),12,0xff65e5b6,true);
            }else paragraph(col,"下单比分未同步",11,0xffffc37f,false);
            paragraph(col,"比分抓取："+freshness(m.optLong("fixtureSampledAt",0L),now),10,0xffa9cad4,false);
            paragraph(col,"统计抓取："+freshness(m.optLong("lastStatsAt",0L),now),10,0xffffc37f,false);
            JSONObject stats=m.optJSONObject("stats");
            if(stats!=null && stats.optBoolean("available",false)){
                paragraph(col,"xG  "+dual(stats,"xg")+"\n射门 "+dual(stats,"shots")+
                    "  射正 "+dual(stats,"on")+"\n禁区内 "+dual(stats,"box")+
                    "  危险进攻 "+dual(stats,"danger"),11,Color.WHITE,false);
            }else paragraph(col,"本场统计缺失，不能凭空判断安全",11,0xffffc37f,false);
            paragraph(col,m.optString("trend","趋势尚未确认"),11,0xffe2cf9d,false);
            JSONObject goal=m.optJSONObject("goalWarning");
            if(goal!=null){
                paragraph(col,"攻势评分："+goal.optString("rating","待核实")+" "+goal.optString("title",""),
                    11,0xffe1d09b,true);
                for(String window:new String[]{"five","ten"}){
                    JSONObject period=goal.optJSONObject(window);
                    if(period!=null)paragraph(col,"最近"+("five".equals(window)?"5":"10")+"分钟：xG "+
                        dual(period,"xg")+" · 射门 "+dual(period,"shots")+" · 射正 "+dual(period,"on"),
                        10,0xffc6dee5,false);
                }
            }
            JSONObject risk=m.optJSONObject("guardRisk");
            if(risk!=null)paragraph(col,"比分路径："+risk.optString("title",risk.optString("level","待复核"))+
                "\n"+risk.optString("reason",""),11,0xffffc37f,false);
            JSONObject review=m.optJSONObject("aiReview");
            if(review!=null)paragraph(col,"手机 AI 复核："+review.optString("conclusion","待核实")+
                "\n风险："+review.optString("risk","未知")+
                "\n动作："+review.optString("action","继续观察"),11,Color.WHITE,false);
            else if(!m.optString("aiReviewError","").isEmpty())
                paragraph(col,"AI："+m.optString("aiReviewError"),10,0xffffc37f,false);
            if(!m.optString("dataError","").isEmpty())
                paragraph(col,"⚠ "+m.optString("dataError"),10,0xffff9d89,false);
            if(!m.optString("eventError","").isEmpty())
                paragraph(col,"事件："+m.optString("eventError"),10,0xffff9d89,false);
            paragraph(col,"────────────",11,0xff536775,false);
        }
        action(col,"从手机刷新赛况",8,true,()->{requestSnapshot();showMatches(false);});
        action(col,"返回",0,false,this::showHome);
        if(previousY>0 && activeScroll!=null){
            final ScrollView scroll=activeScroll;
            scroll.post(()->scroll.scrollTo(0,previousY));
        }
    }
    /**
     * Full round glance in the first viewport; swipe UP to reveal full details.
     * Normal upward scrolling is preserved throughout the long phone report.
     * A completed upward swipe from the initial glance snaps to the details,
     * reducing the number of gestures needed on a small circular display.
     */
    private void showDetail(int nid) {
        JSONObject j=null;
        try {String raw=prefs().getString("alert_"+nid,null);if(raw!=null)j=new JSONObject(raw);}
        catch(Exception ignored){}
        if(j==null){showHome();return;}
        showingDetail=true;showingMatches=false;statusView=null;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        final int d=Math.min(getResources().getDisplayMetrics().widthPixels,
                             getResources().getDisplayMetrics().heightPixels);
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this) {
            private float initialY, initialX;
            private boolean startedOnGlance;
            @Override public boolean dispatchTouchEvent(MotionEvent ev) {
                int type=ev.getActionMasked();
                if(type==MotionEvent.ACTION_DOWN) {
                    initialY=ev.getY();initialX=ev.getX();
                    startedOnGlance=getScrollY()<=dp(8);
                }
                if(type==MotionEvent.ACTION_UP) {
                    float dx=ev.getX()-initialX, dy=ev.getY()-initialY;
                    boolean swipeUp=startedOnGlance && dy<=-dp(38) && Math.abs(dx)<Math.abs(dy)*.65f;
                    boolean handled=super.dispatchTouchEvent(ev);
                    if(swipeUp) post(()->smoothScrollTo(0,d));
                    return handled || swipeUp;
                }
                return super.dispatchTouchEvent(ev);
            }
        };
        activeScroll=scroll;
        scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        FrameLayout.LayoutParams viewport=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);
        root.addView(scroll,viewport);
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);scroll.addView(content);
        WearBrief brief=WearBrief.from(j,System.currentTimeMillis());
        WatchGlanceView glance=new WatchGlanceView(this,brief);
        content.addView(glance,new LinearLayout.LayoutParams(-1,d));
        glance.setClickable(true);
        glance.setOnClickListener(v->scroll.smoothScrollTo(0,d));
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(4),dp(18),dp(4),dp(30));
        LinearLayout.LayoutParams detailParams=new LinearLayout.LayoutParams((int)(d*.84f),-2);
        content.addView(col,detailParams);
        int accent=j.optBoolean("timed",false)?ACCENT:
            ("BROKEN".equals(brief.level)?0xffff8989:0xffffc37f);
        paragraph(col,"完整预警 · 数据与分析",14,ACCENT,true);
        paragraph(col,brief.teams+" · "+brief.score,15,Color.WHITE,true);
        if(brief.picks.length>0) {
            paragraph(col,"我的下单比分",13,ACCENT,true);
            for(WearBrief.Pick bet:brief.picks)
                paragraph(col,bet.label+" · "+bet.state,14,bet.color,true);
        }else paragraph(col,"下单比分未同步，请在手机核对",12,0xffffc37f,true);
        paragraph(col,"风险："+brief.risk,13,accent,true);
        paragraph(col,"提醒："+brief.action,13,0xffffd18c,true);
        paragraph(col,"赛况："+freshness(j.optLong("sourceAt",0L),System.currentTimeMillis()),11,0xffb9dae0,false);
        paragraph(col,"统计："+freshness(j.optLong("statsAt",0L),System.currentTimeMillis())+
            " · "+brief.dataLabel,11,0xffffc37f,false);
        paragraph(col,"原始手机通知",13,ACCENT,true);
        paragraph(col,j.optString("phoneBody",j.optString("line1","赛况待核实")),12,Color.WHITE,false);
        String detail=j.optString("phoneDetail","");
        if(!detail.isEmpty()) {
            paragraph(col,"完整手机分析",13,ACCENT,true);
            paragraph(col,detail,11,0xffc6dee5,false);
        }
        paragraph(col,"数据来自手机 · 不自动结算，需核对平台实时报价",10,0xff9db1bd,false);
        String fixture=j.optString("fixture","");
        if(!j.optBoolean("timed",false) && fixture.matches("[0-9]{1,12}")) {
            TextView confirm=action(col,"已查看 · 停止重复",5,false,()->{});
            confirm.setOnClickListener(v -> {
                confirm.setText("正在发送确认…");
                Wearable.getNodeClient(this).getConnectedNodes().addOnSuccessListener(nodes -> {
                    if(nodes==null || nodes.isEmpty()){confirm.setText("手机未连接 · 可重试");return;}
                    for(Node node:nodes) {
                        Wearable.getMessageClient(this).sendMessage(node.getId(),"/scorepath/ack",
                            fixture.getBytes(StandardCharsets.UTF_8))
                            .addOnSuccessListener(unused -> confirm.setText("已发送 · 请检查手机"))
                            .addOnFailureListener(e -> confirm.setText("发送失败 · 请重试"));
                    }
                }).addOnFailureListener(e -> confirm.setText("手机未连接 · 可重试"));
            });
        }
        action(col,"查看全部比赛",5,true,()->showMatches(true));
        action(col,"返回手表首页",0,false,this::showHome);
        setContentView(root);
    }

}
