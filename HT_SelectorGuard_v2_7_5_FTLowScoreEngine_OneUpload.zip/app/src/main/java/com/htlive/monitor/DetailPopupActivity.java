package com.htlive.monitor;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Native modal detail window launched by tapping any heads-up notification. */
public final class DetailPopupActivity extends Activity {
    private TextView content;
    private String fixtureId;
    private TextView stampView;
    private String notificationDetail="";
    private boolean loading=false;
    @Override public void onCreate(Bundle b){super.onCreate(b);render(getIntent());}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);render(i);}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void render(Intent intent){
        fixtureId=intent.getStringExtra("id");if(fixtureId==null)fixtureId="";
        notificationDetail=intent.getStringExtra("detail");
        if(notificationDetail==null)notificationDetail="";
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        WindowManager.LayoutParams params=getWindow().getAttributes();params.dimAmount=.72f;
        getWindow().setAttributes(params);
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(dp(18),dp(15),dp(18),dp(15));layout.setBackgroundColor(Color.rgb(15,34,51));
        TextView title=new TextView(this);title.setText(intent.getStringExtra("title")!=null?intent.getStringExtra("title"):"赛况详细数据");title.setTextSize(19);title.setTextColor(Color.rgb(87,225,207));title.setTypeface(null,Typeface.BOLD);layout.addView(title);
        stampView=new TextView(this);stampView.setText("正在定位比赛 #"+fixtureId);stampView.setTextSize(11);
        stampView.setTextColor(0xffaec3d5);stampView.setPadding(0,dp(8),0,dp(8));layout.addView(stampView);
        ScrollView scroll=new ScrollView(this);content=new TextView(this);
        content.setText(notificationDetail.isEmpty()?"暂无该场比赛数据。可手动刷新。":notificationDetail);
        content.setTextColor(Color.WHITE);content.setTextSize(14);content.setLineSpacing(dp(4),1f);
        content.setTextIsSelectable(true);scroll.addView(content);
        layout.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);buttons.setPadding(0,dp(10),0,0);
        Button refresh=new Button(this);refresh.setText("刷新实时数据");refresh.setOnClickListener(v->refresh());buttons.addView(refresh,new LinearLayout.LayoutParams(0,dp(52),1));
        Button close=new Button(this);close.setText("关闭");close.setOnClickListener(v->finish());buttons.addView(close,new LinearLayout.LayoutParams(0,dp(52),.7f));
        layout.addView(buttons);
        Button settings=new Button(this);settings.setText("⚙ 打开本场主单／保险单设置");
        settings.setAllCaps(false);
        LinearLayout.LayoutParams settingParams=new LinearLayout.LayoutParams(-1,dp(48));
        settingParams.topMargin=dp(4);
        layout.addView(settings,settingParams);
        settings.setOnClickListener(v->openThisFixtureSettings());
        setContentView(layout);
        getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.97), (int)(getResources().getDisplayMetrics().heightPixels*.86));
        showLastSnapshot();
    }
    // Read the exact fixture's latest monitor snapshot immediately. Never show a different match.
    private void showLastSnapshot(){
        if(!fixtureId.matches("[0-9]{1,12}")){
            content.setText("通知缺少有效比赛ID，无法安全显示其他比赛的数据。");
            stampView.setText("无法识别比赛");
            return;
        }
        try{
            SharedPreferences pref=getSharedPreferences("ht_monitor",MODE_PRIVATE);
            JSONObject snapshot=new JSONObject(pref.getString("snapshot","{}"));
            JSONArray matches=snapshot.optJSONArray("matches");
            JSONObject match=null;
            if(matches!=null)for(int i=0;i<matches.length();i++){
                JSONObject candidate=matches.optJSONObject(i);
                if(candidate!=null && fixtureId.equals(candidate.optString("id"))){match=candidate;break;}
            }
            long updated=snapshot.optLong("updatedAt",0L);
            if(match!=null){
                String report=MatchData.detail(match,updated,"本机监控缓存 / Fixture ID "+fixtureId);
                if(!notificationDetail.isEmpty())report="【点击通知的原始事件】\n"+notificationDetail+"\n\n"+report;
                content.setText(report);
                long age=updated>0?System.currentTimeMillis()-updated:Long.MAX_VALUE;
                stampView.setText("比赛 #"+fixtureId+" · "+(age>180_000L?"⚠ 缓存超过3分钟，点击刷新":"最新已采样赛况（非即时直播）"));
            }else{
                // The notification itself includes the correct fixture's full report.
                stampView.setText("比赛 #"+fixtureId+" · 本机暂无更新缓存，可刷新真实赛况");
            }
        }catch(Exception e){
            stampView.setText("比赛 #"+fixtureId+" · 缓存不可用，可手动刷新");
        }
    }
    private void openThisFixtureSettings(){
        if(!fixtureId.matches("[0-9]{1,12}"))return;
        Intent open=new Intent(this,MainActivity.class);
        open.putExtra(MainActivity.EXTRA_FOCUS_FIXTURE,fixtureId);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(open);
        finish();
    }
    private void refresh(){
        if(!fixtureId.matches("[0-9]{1,12}")){content.setText("无效比赛ID；无法刷新赛况。");return;}
        if(loading)return;
        loading=true;
        stampView.setText("比赛 #"+fixtureId+" · 正在直接读取 API-FOOTBALL…");
        // Preserve the previous report until fresh evidence is actually returned.
        new Thread(()->{
            String text,stamp;
            try{
                SharedPreferences pref=getSharedPreferences("ht_monitor",MODE_PRIVATE);
                String key=pref.getString("apiKey","");
                if(key.isEmpty())throw new Exception("缺少 API-FOOTBALL Key");
                final boolean fullTime=SelectorMonitorSync.fullTime(this,fixtureId);
                JSONObject result=ApiClient.get("fixtures?id="+fixtureId,key);
                JSONArray arr=result.optJSONArray("response");
                if(arr==null||arr.length()==0)throw new Exception("没有这场赛况，可能尚未开赛或接口不可用");
                JSONObject f=arr.getJSONObject(0),teams=f.optJSONObject("teams");
                int hid=teams.getJSONObject("home").optInt("id"),aid=teams.getJSONObject("away").optInt("id");
                String path="fixtures/statistics?fixture="+fixtureId+(fullTime?"":"&half=true");
                JSONObject stats=MatchData.combine(ApiClient.get(path,key).optJSONArray("response"),hid,aid);
                JSONObject match=MatchData.parseFixture(f,stats);
                match.put("period",fullTime?"FT":"HT");
                text=MatchData.detail(match,System.currentTimeMillis(),"手动实时刷新 / API-FOOTBALL / "+(fullTime?"全场":"半场"));
                // API refresh does not recompute the 3/5/10 minute momentum or guard engine.
                text="【提醒】本次是即时比分及累计统计刷新；走势/守分判断仍以后台有效采样为准。\n\n"+text;
                stamp="比赛 #"+fixtureId+" · 实时接口返回（不等于盘口实时变化）";
            }catch(Exception e){
                text=null;
                stamp="比赛 #"+fixtureId+" · 刷新失败："+e.getMessage()+"（保留原数据）";
            }
            final String report=text,heading=stamp;
            runOnUiThread(()->{
                loading=false;
                if(content!=null&&report!=null)content.setText(report);
                if(stampView!=null)stampView.setText(heading);
            });
        },"ht-fixture-detail-refresh").start();
    }
}
