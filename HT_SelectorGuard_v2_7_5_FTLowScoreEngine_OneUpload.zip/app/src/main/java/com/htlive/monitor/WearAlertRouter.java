package com.htlive.monitor;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.content.SharedPreferences;
import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.PutDataMapRequest;
import org.json.JSONArray;
import android.util.Log;
import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Post instantly on phone. Let the watch use a native one-screen notification if it ACKs
 * successful local posting, otherwise re-enable the system's normal notification bridging.
 * No NO_BRIDGING manifest flag: uninstalled/offline/permission-denied wearable falls back.
 */
public final class WearAlertRouter {
    private static final long ACK_TIMEOUT_MS = 3500L;
    private static final ConcurrentHashMap<String, Pending> pending = new ConcurrentHashMap<>();
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private WearAlertRouter() {}

    private static class Pending {
        final NotificationManager manager;
        final Notification.Builder builder;
        final int nid;
        Pending(Context context, Notification.Builder b, int id) {
            manager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            builder=b; nid=id;
        }
        void fallback() {
            // Preserve the first phone vibration, do not fire an additional heads-up alert.
            try{manager.notify(nid, builder.setLocalOnly(false).setOnlyAlertOnce(true).build());}
            catch(SecurityException e){Log.w("HT","Cannot bridge alert without phone permission",e);}
        }
    }

    public static void deliver(Context context, Notification.Builder builder, int nid,
                               JSONObject alert) {
        // Phone notification is immediate, even while the wearable link is being checked.
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        try{nm.notify(nid, builder.setLocalOnly(true).build());}
        catch(SecurityException e){
            // A handset permission error must not prevent a watch with its own
            // notification permission from receiving the alert.
            Log.w("HT","Phone notification permission denied; trying native watch",e);
        }
        String token=UUID.randomUUID().toString();
        Pending state = new Pending(context.getApplicationContext(), builder, nid);
        pending.put(token, state);
        handler.postDelayed(() -> fallback(token), ACK_TIMEOUT_MS);
        try {
            alert.put("token", token);
            byte[] bytes = alert.toString().getBytes(StandardCharsets.UTF_8);
            // Durable delivery in addition to low-latency MessageClient. A briefly
            // disconnected watch can pick up an alert on reconnection. Native watch
            // code refuses to buzz if the alert is already over two minutes old.
            try {
                PutDataMapRequest saved=PutDataMapRequest.create("/scorepath/alert/"+nid);
                saved.getDataMap().putString("json",alert.toString());
                saved.getDataMap().putLong("time",alert.optLong("time",0L));
                Wearable.getDataClient(context.getApplicationContext())
                    .putDataItem(saved.asPutDataRequest().setUrgent())
                    .addOnFailureListener(e->Log.w("HT","Durable watch alert failed",e));
            } catch(Exception e){Log.w("HT","Unable to cache watch alert",e);}
            // Resolve connected nodes directly; some Wear OS builds omit capability results.
            // Only installed, same-package/signature peers can receive the message;
            // if no watch confirms posting, the normal notification bridge takes over.
            Wearable.getNodeClient(context.getApplicationContext()).getConnectedNodes()
                .addOnSuccessListener(nodes -> {
                    if(nodes==null || nodes.isEmpty()) { fallback(token); return; }
                    for(Node node:nodes) {
                        Wearable.getMessageClient(context.getApplicationContext())
                            .sendMessage(node.getId(), "/scorepath/alert", bytes)
                            .addOnFailureListener(e -> {
                                Log.w("HT", "Wear message failed: " + e.getMessage());
                                fallback(token);
                            });
                    }
                    // Task success means enqueued, not displayed; await native watch ACK.
                })
                .addOnFailureListener(e -> fallback(token));
        } catch(Exception e) { fallback(token); }
    }

    public static void confirm(String token) {
        if (token != null && !token.isEmpty()) pending.remove(token);
    }

    private static void fallback(String token) {
        Pending p=pending.remove(token);
        if(p!=null) p.fallback();
    }

    /** Best-effort cleanup on the watch; phone notification cancellation remains authoritative. */
    public static void removeFixtures(Context context, Set<String> ids) {
        if (ids==null || ids.isEmpty())return;
        try {
            // Delete durable alerts after halftime; otherwise an offline watch could
            // receive a now-irrelevant stored score after the match was removed.
            SharedPreferences prefs=context.getSharedPreferences("ht_monitor",Context.MODE_PRIVATE);
            for(String id:ids){
                JSONArray notices=new JSONArray(prefs.getString("notice_ids_"+id,"[]"));
                for(int i=0;i<notices.length();i++){
                    int nid=notices.optInt(i,-1);
                    if(nid<0)continue;
                    Uri uri=Uri.parse("wear://*/scorepath/alert/"+nid);
                    Wearable.getDataClient(context).deleteDataItems(uri,DataClient.FILTER_LITERAL)
                        .addOnFailureListener(e->Log.w("HT","Unable to clear old watch alert",e));
                }
            }
            JSONObject message=new JSONObject();
            org.json.JSONArray list=new org.json.JSONArray();
            for(String id:ids)list.put(id);
            message.put("ids",list);
            byte[] bytes=message.toString().getBytes(StandardCharsets.UTF_8);
            Wearable.getNodeClient(context).getConnectedNodes()
                .addOnSuccessListener(nodes -> {
                    for(Node node:nodes)
                        Wearable.getMessageClient(context).sendMessage(node.getId(),"/scorepath/remove",bytes);
                });
        } catch(Exception e) { Log.w("HT", "Wear cleanup unavailable", e); }
    }
}
